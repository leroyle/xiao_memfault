#ifndef __CLI_H__
#define __CLI_H__
// App version
#define VERSION_MAX 50

EmbeddedCli * cliSetup( const char * appVersionString);

#endif

