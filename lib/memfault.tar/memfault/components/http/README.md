# http

HTTP client API, to post coredumps and events directly to the Memfault service
from devices. See documentation in header files for details on the API itself.
