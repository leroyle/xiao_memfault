#ifndef __MEMFAULTMAIN_H__
#define __MEMFAULTMAIN_H__

 void memfaultSetup(void);
 void memfaultLoop(void);
 void memfaultBefore(void);

#endif
